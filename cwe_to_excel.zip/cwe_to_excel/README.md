# cwe_to_excel

Build a CWE remediation lookup `.xlsx` from MITRE's official XML feed
(<https://cwe.mitre.org/data/xml/cwec_latest.xml.zip>).

## Install

```bash
pip install -r requirements.txt
```

Requires Python 3.9+.

## Usage

Run from the directory that contains the `cwe_to_excel/` package folder:

```bash
# Latest CWE version, output to ./cwe_lookup.xlsx
python -m cwe_to_excel

# Custom output path
python -m cwe_to_excel -o /path/to/cwe.xlsx

# Pin to a specific CWE version (for reproducibility)
python -m cwe_to_excel --version 4.20
```

## Output

A single `.xlsx` with two sheets:

- **CWE Lookup** — one row per Weakness (~960 rows on v4.20). Header row is
  frozen, autofilter is enabled, long text wraps within cells.
- **Metadata** — CWE version, source URL, generation timestamp UTC, total
  weaknesses, count of any cells that hit Excel's 32,767-char limit.

### Columns

`CWE-ID`, `Name`, `Abstraction`, `Status`, `Description`, `Extended Description`,
`Common Consequences`, `Potential Mitigations`, `Detection Methods`,
`Demonstrative Examples`, `Observed Examples`, `Related Weaknesses`,
`Applicable Platforms`, `References`

### Formatting rules

- XHTML markup (`<p>`, `<br/>`, `<li>`, etc.) inside description fields is
  converted to plain text with sensible newlines.
- Multi-valued fields (e.g. multiple mitigations or consequences) are joined
  with `\n---\n`.
- Cells exceeding Excel's 32,767-char hard limit are truncated with a
  ` […truncated]` marker. The Metadata sheet reports the truncation count.
- `References` cells fully resolve `External_Reference_ID` tokens to
  `Author. (Year). "Title". Publisher. URL` strings.

## Project layout

```
cwe_to_excel/
  __init__.py
  __main__.py     # `python -m cwe_to_excel` entry
  download.py     # fetch + unzip + version detect
  parse.py        # XML -> list[dict]
  transform.py    # XHTML -> plain text, truncation, block joining
  export.py       # write .xlsx with formatting + metadata sheet
  main.py         # orchestrates and accepts --version, --output args
```

## Programmatic use

```python
from pathlib import Path
from cwe_to_excel.download import download_xml
from cwe_to_excel.parse import parse_weaknesses
from cwe_to_excel.export import write_workbook

xml_bytes, version, source_url = download_xml()      # or download_xml("4.20")
rows = parse_weaknesses(xml_bytes)                   # list[dict]
write_workbook(rows, version, source_url, Path("cwe_lookup.xlsx"))
```
