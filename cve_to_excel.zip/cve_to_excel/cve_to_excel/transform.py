"""Pure helpers: CVSS vector parsing, truncation, datetime formatting."""

from __future__ import annotations

# Excel hard cap on a single cell
CELL_LIMIT = 32_767
TRUNCATE_MARKER = " […truncated]"

# CVSS v3.x metric code -> human-readable value
# Reference: https://www.first.org/cvss/v3.1/specification-document
V3_METRIC_VALUES: dict[str, dict[str, str]] = {
    "AV": {"N": "Network", "A": "Adjacent", "L": "Local", "P": "Physical"},
    "AC": {"L": "Low", "H": "High"},
    "PR": {"N": "None", "L": "Low", "H": "High"},
    "UI": {"N": "None", "R": "Required"},
    "S":  {"U": "Unchanged", "C": "Changed"},
    "C":  {"N": "None", "L": "Low", "H": "High"},
    "I":  {"N": "None", "L": "Low", "H": "High"},
    "A":  {"N": "None", "L": "Low", "H": "High"},
}


def parse_cvss_v3_vector(vector: str) -> dict[str, str]:
    """Parse a CVSS v3.x vector string into a metric -> human-value dict.

    Example input:  'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H'
    Example output: {'AV': 'Network', 'AC': 'Low', 'PR': 'None', 'UI': 'None', ...}

    Unknown codes are returned as-is. An empty/invalid vector returns {}.
    """
    if not vector or not isinstance(vector, str):
        return {}
    out: dict[str, str] = {}
    for part in vector.split("/"):
        if ":" not in part or part.startswith("CVSS"):
            continue
        key, _, code = part.partition(":")
        mapping = V3_METRIC_VALUES.get(key)
        out[key] = mapping.get(code, code) if mapping else code
    return out


def format_datetime(s: str) -> str:
    """Normalize an NVD ISO timestamp to 'YYYY-MM-DD HH:MM:SS' (UTC, no tz suffix).

    NVD timestamps look like '2024-01-15T10:30:00.000' or '2024-01-15T10:30:00.000Z'.
    Bad/empty input is returned unchanged.
    """
    if not s or not isinstance(s, str):
        return ""
    # Strip fractional seconds and timezone marker for compact display
    core = s.split(".")[0].split("+")[0].rstrip("Z")
    return core.replace("T", " ")


def truncate(text: str) -> str:
    """Truncate to Excel's per-cell limit, appending a marker if cut."""
    if len(text) <= CELL_LIMIT:
        return text
    return text[: CELL_LIMIT - len(TRUNCATE_MARKER)] + TRUNCATE_MARKER


def pick_primary(metrics_list: list[dict] | None) -> dict | None:
    """Return the entry with type == 'Primary', else the first entry, else None."""
    if not metrics_list:
        return None
    for m in metrics_list:
        if m.get("type") == "Primary":
            return m
    return metrics_list[0]
