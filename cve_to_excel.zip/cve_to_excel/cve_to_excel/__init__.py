"""cve_to_excel — Build a per-year CVE lookup workbook from fkie-cad NVD JSON feeds."""

__version__ = "1.0.0"
