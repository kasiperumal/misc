================================================================================
  OpenSSF SCORER
  OpenSSF Scorecard reporter for Maven libraries
================================================================================

CONTENTS
--------
  1. Overview
  2. Architecture
  3. Project structure
  4. Prerequisites
  5. Installation
  6. Configuration (.env)
  7. Input format
  8. Running the tool
  9. Output format
 10. Caching
 11. Logging
 12. Status value reference
 13. Troubleshooting
 14. API references
 15. Limitations


────────────────────────────────────────────────────────────────────────────────
1. OVERVIEW
────────────────────────────────────────────────────────────────────────────────

OpenSSF Scorer automates the collection of OpenSSF Scorecard scores for Maven
library dependencies listed in an Excel workbook.

For each library it:
  (a) Resolves the library's GitHub source repository via the deps.dev API
      (no access to Maven Central required)
  (b) Fetches the OpenSSF Scorecard score for that repository
  (c) Writes a two-tab Excel report with a summary and per-check detail


────────────────────────────────────────────────────────────────────────────────
2. ARCHITECTURE
────────────────────────────────────────────────────────────────────────────────

  ┌─────────────────────────────────────────────────────────────────────────┐
  │                         INPUT: sample_input.xlsx                        │
  │  ┌──────────┐  ┌──────────┐  ┌──────────┐   Multiple tabs, each with   │
  │  │ Backend  │  │ Logging  │  │ Testing  │   "Library Name" +            │
  │  └──────────┘  └──────────┘  └──────────┘   "Current Version" columns  │
  └────────────────────────────┬────────────────────────────────────────────┘
                               │ read all tabs → flat list of rows
                               ▼
  ┌─────────────────────────────────────────────────────────────────────────┐
  │                         ossf_scorer.py                                  │
  │                                                                         │
  │  1. Read .env config                                                    │
  │  2. Load JSON cache (./cache/ossf_cache.json)                           │
  │  3. Preflight: ping both APIs                                           │
  │  4. For each row (parallel, MAX_WORKERS threads):                       │
  │                                                                         │
  │     ┌──────────────────────────────────────────────────────────────┐   │
  │     │  STEP 1 – deps.dev API                                       │   │
  │     │  GET api.deps.dev/v3/systems/maven/packages/{lib}/           │   │
  │     │            versions/{ver}                                    │   │
  │     │                                                              │   │
  │     │  Extract from response:                                      │   │
  │     │    Primary  → relatedProjects[relationType=SOURCE_REPO]      │   │
  │     │    Fallback → links[label=SOURCE_REPO]  (regex parse)       │   │
  │     │                                                              │   │
  │     │  Result: github.com/owner/repo   OR   error status          │   │
  │     └──────────────────────────────┬───────────────────────────────┘   │
  │                                    │ github.com/owner/repo              │
  │     ┌──────────────────────────────▼───────────────────────────────┐   │
  │     │  STEP 2 – Scorecard API                                      │   │
  │     │  GET api.scorecard.dev/projects/github.com/owner/repo        │   │
  │     │                                                              │   │
  │     │  Extract: score (0-10), date, checks[]                      │   │
  │     └──────────────────────────────────────────────────────────────┘   │
  │                                                                         │
  │  5. Save cache (on completion or Ctrl-C)                               │
  │  6. Write output Excel                                                  │
  └────────────────────────────┬────────────────────────────────────────────┘
                               │
  ┌────────────────────────────▼────────────────────────────────────────────┐
  │                      OUTPUT: output/ossf_report.xlsx                    │
  │                                                                         │
  │  Tab 1 – Summary                                                        │
  │  ┌────────────────┬─────────┬───────────┬──────────────┬───────┬──────┐ │
  │  │ Library Name   │ Version │ OpenSSF Score│ Scorecard Date│Repo  │Status│ │
  │  ├────────────────┼─────────┼───────────┼──────────────┼───────┼──────┤ │
  │  │ org.spring...  │ 3.4.4   │   6.3     │ 2026-04-20 ..│github │  OK  │ │
  │  └────────────────┴─────────┴───────────┴──────────────┴───────┴──────┘ │
  │                                                                         │
  │  Tab 2 – Check Details  (one row per library × check)                  │
  │  ┌──────────┬────────┬──────────────┬───────┬──────────┬────────┬─────┐ │
  │  │Library   │Version │ Check Name   │Score  │ Reason   │Details │Docs │ │
  │  ├──────────┼────────┼──────────────┼───────┼──────────┼────────┼─────┤ │
  │  │org.spring│ 3.4.4  │ Code-Review  │  0    │Found 0/30│  ...   │ URL │ │
  │  │org.spring│ 3.4.4  │ Maintained   │  10   │30 commits│        │ URL │ │
  │  │  ...     │  ...   │   ...        │  ...  │   ...    │  ...   │ ... │ │
  │  └──────────┴────────┴──────────────┴───────┴──────────┴────────┴─────┘ │
  └─────────────────────────────────────────────────────────────────────────┘

  Side-car components
  ───────────────────
  • cache/ossf_cache.json  – persists API responses across runs (24h TTL)
  • logs/ossf_scorer.log   – rotating log file, always DEBUG level
  • .env                   – all runtime configuration (no CLI flags needed)


────────────────────────────────────────────────────────────────────────────────
3. PROJECT STRUCTURE
────────────────────────────────────────────────────────────────────────────────

  ossf-scorer/
  ├── ossf_scorer.py        Main script (entry point)
  ├── sample_input.xlsx     Example input with 3 tabs and 9 rows
  ├── requirements.txt      Python dependencies
  ├── .env.example          Config template – copy to .env and edit
  ├── README.txt            This file
  ├── cache/
  │   └── ossf_cache.json   Auto-created on first run
  ├── logs/
  │   └── ossf_scorer.log   Auto-created; rotates at 5 MB (3 backups kept)
  └── output/
      └── ossf_report.xlsx  Auto-created / overwritten on each run


────────────────────────────────────────────────────────────────────────────────
4. PREREQUISITES
────────────────────────────────────────────────────────────────────────────────

  • Python 3.10 or later  (3.10+ required for X | Y type hints)
  • Network access to:
      https://api.deps.dev        (Google deps.dev – no auth required)
      https://api.scorecard.dev   (OpenSSF Scorecard – no auth required)
  • If behind a corporate proxy, set HTTPS_PROXY in .env (see Section 6)


────────────────────────────────────────────────────────────────────────────────
5. INSTALLATION
────────────────────────────────────────────────────────────────────────────────

  Step 1 – (Recommended) create a virtual environment:

      python -m venv .venv

      # Windows
      .venv\Scripts\activate

      # macOS / Linux
      source .venv/bin/activate

  Step 2 – Install dependencies:

      pip install -r requirements.txt

  Step 3 – Create your config file:

      # Windows
      copy .env.example .env

      # macOS / Linux
      cp .env.example .env

      Then open .env in any text editor and adjust values as needed.


────────────────────────────────────────────────────────────────────────────────
6. CONFIGURATION (.env)
────────────────────────────────────────────────────────────────────────────────

  All settings live in the .env file in the project root.

  Variable           Default                        Description
  ─────────────────  ─────────────────────────────  ──────────────────────────
  INPUT_FILE         ./sample_input.xlsx            Path to input Excel
  OUTPUT_FILE        ./output/ossf_report.xlsx      Path to output Excel
  CACHE_FILE         ./cache/ossf_cache.json        Path to JSON cache
  LOG_FILE           ./logs/ossf_scorer.log         Path to log file
  MAX_WORKERS        5                              Parallel threads
  REQUEST_TIMEOUT    30                             API timeout (seconds)
  CACHE_TTL_HOURS    24                             Cache entry lifetime
  CLEAR_CACHE        false                          Force cache refresh
  LOG_LEVEL          INFO                           Console log verbosity
  HTTPS_PROXY        (blank)                        Corporate proxy URL

  HTTPS_PROXY example values:
    http://proxy.company.com:8080
    http://user:password@proxy.company.com:8080

  SSL NOTE: If your corporate network performs TLS inspection and you see
  SSL certificate errors, set the standard environment variable:
    REQUESTS_CA_BUNDLE=/path/to/your/corporate-ca-bundle.pem
  This is an OS-level variable, not an .env setting.


────────────────────────────────────────────────────────────────────────────────
7. INPUT FORMAT
────────────────────────────────────────────────────────────────────────────────

  • File format  : .xlsx (Excel workbook)
  • Tabs         : Any number; tab names are not significant
  • Required columns (exact names, case-sensitive):

      Library Name        Maven coordinate: groupId:artifactId
                          Example: org.springframework.boot:spring-boot-dependencies

      Current Version     Version string
                          Example: 3.4.4

  • Rows with blank Library Name or Current Version are silently skipped
  • Tabs missing either column are skipped with a warning in the log
  • The same library+version may appear in multiple tabs; each occurrence
    is processed as a separate output row (no deduplication), but the
    cache ensures only one API call is made per unique combination


────────────────────────────────────────────────────────────────────────────────
8. RUNNING THE TOOL
────────────────────────────────────────────────────────────────────────────────

  Basic run (uses .env settings):

      python ossf_scorer.py

  Force a full cache refresh for this run:

      # Edit .env: set CLEAR_CACHE=true, run, then set back to false
      # Or set as an environment variable temporarily:

      # Windows (PowerShell)
      $env:CLEAR_CACHE="true"; python ossf_scorer.py

      # macOS / Linux
      CLEAR_CACHE=true python ossf_scorer.py

  Process a different input file without editing .env:

      # Windows (PowerShell)
      $env:INPUT_FILE="./my_libs.xlsx"; python ossf_scorer.py

      # macOS / Linux
      INPUT_FILE=./my_libs.xlsx python ossf_scorer.py

  The tool performs a preflight check (pings both APIs) before processing
  any rows. If either API is unreachable it exits immediately with a clear
  error message pointing to HTTPS_PROXY configuration.

  Press Ctrl-C at any time to abort – the cache is saved before exit so
  completed rows are not re-fetched on the next run.


────────────────────────────────────────────────────────────────────────────────
9. OUTPUT FORMAT
────────────────────────────────────────────────────────────────────────────────

  The output workbook (output/ossf_report.xlsx) contains two tabs.

  ── Tab 1: Summary ──────────────────────────────────────────────────────────

  One row per input row (no deduplication).

  Column            Description
  ────────────────  ────────────────────────────────────────────────────────
  Library Name      Maven coordinate from input
  Current Version   Version from input
  OpenSSF Score        Overall Scorecard score (0.0 – 10.0), blank if not scored
  Scorecard Date    Date the score was last computed, with human-friendly
                    relative label: "2026-04-20 (5 days ago)"
  Repo URL          GitHub repo identified by deps.dev, e.g.
                    github.com/spring-projects/spring-boot
  Status            Result code (see Section 12 for full list)

  ── Tab 2: Check Details ────────────────────────────────────────────────────

  One row per (library × check). Contains ~14–18 rows per successfully
  scored library. Libraries with non-OK status produce no detail rows.

  Column                Description
  ────────────────────  ──────────────────────────────────────────────────
  Library Name          Maven coordinate
  Current Version       Version string
  Check Name            Scorecard check, e.g. Code-Review, Maintained
  Check Score           0–10, or -1 meaning "not applicable / no data"
                        (e.g. Signed-Releases when the repo has no releases)
  Reason                Human-readable explanation from the Scorecard API
  Details               Detailed warnings/info, one per line in the cell
                        (blank when the API returns null for this check)
  Documentation Short   One-line description of what the check measures
  Documentation URL     Link to the official Scorecard check documentation

  Formatting applied to both tabs:
  • Header row: dark blue background, white bold text, centre-aligned
  • Header row frozen (stays visible while scrolling)
  • All cells: wrap-text enabled, top-aligned
  • Column widths pre-set for readability (Library Name = 55 chars, etc.)


────────────────────────────────────────────────────────────────────────────────
10. CACHING
────────────────────────────────────────────────────────────────────────────────

  Why it exists:
    Both APIs are public and rate-limited. A workbook with 200 unique
    libraries takes several minutes on the first run. On subsequent runs,
    results are served from cache in milliseconds.

  How it works:
    • cache/ossf_cache.json is loaded at startup
    • Two sections: "deps_dev" (repo resolution) and "scorecard" (scores)
    • Each entry has a "cached_at" ISO timestamp
    • On lookup: if cached_at is older than CACHE_TTL_HOURS (default 24),
      the entry is treated as a miss and re-fetched
    • Cache is written at the end of every run, and on Ctrl-C interrupt

  Cache structure (for reference):
    {
      "deps_dev": {
        "org.springframework.boot:spring-boot-dependencies@3.4.4": {
          "repo":      "github.com/spring-projects/spring-boot",
          "status":    "OK",
          "cached_at": "2026-04-25T10:00:00+00:00"
        }
      },
      "scorecard": {
        "github.com/spring-projects/spring-boot": {
          "score":     6.3,
          "date":      "2026-04-20",
          "checks":    [...],
          "status":    "OK",
          "cached_at": "2026-04-25T10:00:00+00:00"
        }
      }
    }

  Clearing the cache:
    Option A – Set CLEAR_CACHE=true in .env for one run (then reset to false)
    Option B – Delete cache/ossf_cache.json manually

  Note: Error statuses (e.g. "Not scored", "Repo not found") are also
  cached. This prevents the tool from hammering the API for libraries that
  are known to be absent. Clear the cache if you believe a library has
  since been added to the Scorecard dataset.


────────────────────────────────────────────────────────────────────────────────
11. LOGGING
────────────────────────────────────────────────────────────────────────────────

  Two log destinations run simultaneously:

  Console (stdout)
    • Level controlled by LOG_LEVEL in .env (default: INFO)
    • Shows progress alongside the tqdm progress bar
    • Format: "LEVEL    message"

  Log file (logs/ossf_scorer.log)
    • Always captures DEBUG level (full request URLs, cache hits, timing)
    • Format: "YYYY-MM-DD HH:MM:SS  LEVEL    message"
    • Rotating: max 5 MB per file, 3 backup files kept
      (ossf_scorer.log, ossf_scorer.log.1, ossf_scorer.log.2, ...)

  Each run appends to the log with a header:
    =================================================================
      OpenSSF Scorer  –  Run started 2026-04-25 14:30:00
    =================================================================

  Log content per level:
    DEBUG   → API request URLs, response status codes, cache hits/misses
    INFO    → Run config, per-tab row counts, each OK result with score
    WARNING → Non-OK statuses (Not scored, Repo not found, etc.)
    ERROR   → API failures, file I/O errors, unexpected exceptions

  To enable DEBUG on the console (for live troubleshooting):
    Set LOG_LEVEL=DEBUG in .env


────────────────────────────────────────────────────────────────────────────────
12. STATUS VALUE REFERENCE
────────────────────────────────────────────────────────────────────────────────

  Status                           Meaning
  ──────────────────────────────   ──────────────────────────────────────────
  OK                               Score fetched successfully
  Not scored                       Scorecard has no data for this repo
                                   (repo may not be in the weekly scan set)
  Not scored (non-GitHub repo)     deps.dev found a source repo but it is
                                   not on GitHub (Scorecard is GitHub-only)
  Repo not found                   deps.dev returned a 200 response but no
                                   SOURCE_REPO link was present
  Library not found in deps.dev    deps.dev returned 404 for this coordinate
  Rate limited                     Scorecard API returned 429 after retries
  deps.dev error: <detail>         Network error or unexpected HTTP status
                                   when calling deps.dev
  scorecard error: <detail>        Network error or unexpected HTTP status
                                   when calling Scorecard API
  Unexpected error: <detail>       Unhandled exception in the processing
                                   thread (see log file for stack trace)


────────────────────────────────────────────────────────────────────────────────
13. TROUBLESHOOTING
────────────────────────────────────────────────────────────────────────────────

  Problem: "Cannot reach deps.dev API" on startup
    → Check HTTPS_PROXY in .env
    → Ask your network team to whitelist api.deps.dev and api.scorecard.dev
    → Confirm you can curl https://api.deps.dev manually from the machine

  Problem: SSL certificate verification error
    → Your proxy may perform TLS interception
    → Set: REQUESTS_CA_BUNDLE=/path/to/corporate-ca-bundle.pem
      (OS environment variable, not in .env)
    → Obtain the CA bundle from your IT security team

  Problem: All rows show "Not scored"
    → The libraries may be in the deps.dev dataset but Scorecard has not
      scanned them (Scorecard covers ~1 million most-popular repos)
    → Check the Repo URL column – if it's blank the repo was not resolved
    → Try: https://scorecard.dev/viewer/?uri=<repo> in a browser

  Problem: OpenSSF Score is blank for some rows
    → Check the Status column for the specific reason
    → Check logs/ossf_scorer.log for WARNING or ERROR entries

  Problem: Stale scores (score hasn't updated)
    → Scorecard re-scans repos weekly; the "Scorecard Date" column shows
      when the score was last computed by OpenSSF
    → Set CLEAR_CACHE=true to force re-fetch from the API

  Problem: Run is very slow
    → Increase MAX_WORKERS (try 10) if the proxy supports more connections
    → Ensure cache is populated (second run of same input is much faster)

  Problem: Output Excel has blank "Check Details" tab
    → Only rows with Status=OK produce detail rows
    → If all rows have non-OK status, the tab will have headers only


────────────────────────────────────────────────────────────────────────────────
14. API REFERENCES
────────────────────────────────────────────────────────────────────────────────

  deps.dev (Google Open Source Insights)
    Documentation : https://docs.deps.dev/api/v3/
    Endpoint used : GET /v3/systems/maven/packages/{name}/versions/{version}
    Auth          : None required
    Rate limits   : Not publicly documented; respectful use recommended

  OpenSSF Scorecard
    Documentation : https://github.com/ossf/scorecard
    Endpoint used : GET https://api.scorecard.dev/projects/{repo}
    Auth          : None required
    Data license  : CDLA Permissive 2.0
    Rate limits   : Not publicly documented; tool retries on 429


────────────────────────────────────────────────────────────────────────────────
15. LIMITATIONS
────────────────────────────────────────────────────────────────────────────────

  • Maven only
    The tool is designed exclusively for Maven (groupId:artifactId) coordinates.
    Other ecosystems (npm, PyPI, NuGet) are not supported.

  • GitHub only
    Scorecard currently covers GitHub-hosted projects only. Libraries whose
    source is on GitLab, Bitbucket, or internal hosting will receive
    "Not scored (non-GitHub repo)" status.

  • Score is per-repo, not per-version
    The Scorecard score reflects the current state of the repository, not
    the specific version you have declared. A library at v3.4.4 and v3.5.0
    will receive the same Scorecard score because they share a repo.

  • BOM / aggregator artifacts
    BOM artifacts such as spring-boot-dependencies score the parent
    repository (spring-boot), not the BOM module itself. This is correct
    behaviour – the score reflects the project's security practices.

  • Scorecard coverage
    Not every public GitHub repository is scanned by Scorecard. The weekly
    job covers approximately the 1 million most-depended-upon projects.
    Niche or internal-fork libraries may return "Not scored".

================================================================================
