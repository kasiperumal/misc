"""Parse NVD 2.0 CVE records into a list of flat dicts ready for Excel export.

Rejected CVEs (`vulnStatus == 'Rejected'`) are filtered out per project requirements.
"""

from __future__ import annotations

from collections import Counter

from .transform import format_datetime, parse_cvss_v3_vector, pick_primary

REJECTED_STATUS = "Rejected"

# Only CVEs whose v3.x OR v4.0 severity is in this set are written to the workbook.
# CVEs with no severity at all (e.g. Awaiting Analysis) are filtered out.
INCLUDED_SEVERITIES = frozenset({"CRITICAL", "HIGH"})


def _unwrap(record: dict) -> dict:
    """Return the inner CVE object regardless of {'cve': {...}} wrapping."""
    inner = record.get("cve")
    return inner if isinstance(inner, dict) else record


def _description(cve: dict) -> str:
    descs = cve.get("descriptions", []) or []
    for d in descs:
        if d.get("lang") == "en":
            return d.get("value", "")
    if descs:
        d = descs[0]
        return f"[lang: {d.get('lang', '?')}] {d.get('value', '')}"
    return ""


def _cwe_ids(cve: dict) -> str:
    out: list[str] = []
    seen: set[str] = set()
    for w in cve.get("weaknesses", []) or []:
        for d in w.get("description", []) or []:
            if d.get("lang") != "en":
                continue
            val = (d.get("value") or "").strip()
            if val and val not in seen:
                seen.add(val)
                out.append(val)
    return ", ".join(out)


def _select_v3(metrics: dict) -> tuple[dict | None, str]:
    """Prefer CVSS v3.1, fall back to v3.0. Returns (entry, version_label)."""
    v31 = pick_primary(metrics.get("cvssMetricV31"))
    if v31:
        return v31, "3.1"
    v30 = pick_primary(metrics.get("cvssMetricV30"))
    if v30:
        return v30, "3.0"
    return None, ""


def _flatten_cpe_match(cpe: dict, products: dict[tuple[str, str], set[str]]) -> None:
    if not cpe.get("vulnerable", True):
        return
    criteria = cpe.get("criteria") or ""
    parts = criteria.split(":")
    if len(parts) < 5:
        return
    vendor = parts[3] or "*"
    product = parts[4] or "*"
    version_in_cpe = parts[5] if len(parts) > 5 else "*"

    start_incl = cpe.get("versionStartIncluding")
    start_excl = cpe.get("versionStartExcluding")
    end_incl = cpe.get("versionEndIncluding")
    end_excl = cpe.get("versionEndExcluding")

    if start_incl or start_excl or end_incl or end_excl:
        left = (
            f"≥ {start_incl}" if start_incl
            else (f"> {start_excl}" if start_excl else "")
        )
        right = (
            f"≤ {end_incl}" if end_incl
            else (f"< {end_excl}" if end_excl else "")
        )
        bits = [b for b in (left, right) if b]
        range_str = " and ".join(bits) if bits else "any"
    elif version_in_cpe and version_in_cpe not in ("*", "-"):
        range_str = version_in_cpe
    else:
        range_str = "any"

    products.setdefault((vendor, product), set()).add(range_str)


def _walk_node(node: dict, products: dict[tuple[str, str], set[str]]) -> None:
    for cpe in node.get("cpeMatch", []) or []:
        _flatten_cpe_match(cpe, products)
    for child in node.get("children", []) or []:
        _walk_node(child, products)


def _affected_products(cve: dict) -> str:
    products: dict[tuple[str, str], set[str]] = {}
    for config in cve.get("configurations", []) or []:
        for node in config.get("nodes", []) or []:
            _walk_node(node, products)
    if not products:
        return ""
    lines = []
    for (vendor, product) in sorted(products):
        ranges = sorted(products[(vendor, product)])
        lines.append(f"{vendor}:{product} ({', '.join(ranges)})")
    return "\n".join(lines)


def parse_records(records: list[dict]) -> tuple[list[dict], dict]:
    """Parse a list of NVD CVE records into flat dicts.

    Returns (rows, stats) where stats includes per-status counts and indicators
    used by the Metadata sheet.
    """
    rows: list[dict] = []
    status_counts: Counter[str] = Counter()
    severity_counts: Counter[str] = Counter()
    rejected_count = 0
    filtered_by_severity = 0
    no_score_count = 0
    no_v3 = 0
    has_v4 = 0

    for rec in records:
        cve = _unwrap(rec)
        status = cve.get("vulnStatus", "")
        status_counts[status] += 1

        if status == REJECTED_STATUS:
            rejected_count += 1
            continue

        metrics = cve.get("metrics", {}) or {}
        v3_entry, v3_label = _select_v3(metrics)
        v3_data = (v3_entry or {}).get("cvssData", {}) if v3_entry else {}
        vector = v3_data.get("vectorString", "")
        parsed = parse_cvss_v3_vector(vector)

        v4_entry = pick_primary(metrics.get("cvssMetricV40"))
        v4_data = (v4_entry or {}).get("cvssData", {}) if v4_entry else {}

        v3_sev = v3_data.get("baseSeverity", "") or ""
        v4_sev = v4_data.get("baseSeverity", "") or ""

        # Severity filter: keep only if v3.x OR v4.0 severity is CRITICAL/HIGH
        if v3_sev not in INCLUDED_SEVERITIES and v4_sev not in INCLUDED_SEVERITIES:
            if not v3_sev and not v4_sev:
                no_score_count += 1
            else:
                filtered_by_severity += 1
                # Track what severities we excluded so the user can see the breakdown
                severity_counts[v3_sev or v4_sev or "(none)"] += 1
            continue

        # Track the severity that caused inclusion (v3 wins for the counter if both present)
        effective_sev = v3_sev if v3_sev in INCLUDED_SEVERITIES else v4_sev
        severity_counts[effective_sev] += 1

        if not v3_entry:
            no_v3 += 1
        if v4_entry:
            has_v4 += 1

        rows.append({
            "CVE-ID": cve.get("id", ""),
            "Status": status,
            "Published Date (UTC)": format_datetime(cve.get("published", "")),
            "Last Modified Date (UTC)": format_datetime(cve.get("lastModified", "")),
            "Description": _description(cve),
            "CWE-IDs": _cwe_ids(cve),
            "CVSS v3.x Version": v3_label,
            "CVSS v3.x Base Score": v3_data.get("baseScore", ""),
            "CVSS v3.x Severity": v3_data.get("baseSeverity", ""),
            "CVSS v3.x Vector": vector,
            "CVSS v4.0 Base Score": v4_data.get("baseScore", ""),
            "CVSS v4.0 Severity": v4_data.get("baseSeverity", ""),
            "Attack Vector": parsed.get("AV", ""),
            "Attack Complexity": parsed.get("AC", ""),
            "Privileges Required": parsed.get("PR", ""),
            "User Interaction": parsed.get("UI", ""),
            "Affected Products": _affected_products(cve),
        })

    # Sort by CVE numeric suffix
    def _sort_key(r: dict) -> tuple[int, int]:
        cid = r["CVE-ID"]
        try:
            _, year, num = cid.split("-")
            return int(year), int(num)
        except ValueError:
            return 0, 0
    rows.sort(key=_sort_key)

    stats = {
        "status_counts": dict(status_counts),
        "severity_counts": dict(severity_counts),
        "rejected_filtered_out": rejected_count,
        "filtered_by_severity": filtered_by_severity,
        "no_score_filtered_out": no_score_count,
        "no_v3_score": no_v3,
        "has_v4_score": has_v4,
        "included": len(rows),
        "total_records": len(records),
        "included_severities": sorted(INCLUDED_SEVERITIES),
    }
    return rows, stats
