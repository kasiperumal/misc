#!/usr/bin/env python3
"""
OpenSSF Scorer
-----------
Reads a multi-tab Excel workbook of Maven libraries, resolves each
library's GitHub source repo via the deps.dev API, fetches its OpenSSF
Scorecard score, and writes a two-tab Excel report.

Tabs in output:
  Summary      - one row per input row  (Library, Version, Score, Date, Repo, Status)
  Check Details - one row per check     (Library, Version, Check Name, Score, ...)
"""

import json
import logging
import logging.handlers
import os
import re
import signal
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import pandas as pd
import requests
from dotenv import load_dotenv
from openpyxl.styles import Alignment, Font, PatternFill
from requests.adapters import HTTPAdapter
from tqdm import tqdm
from urllib3.util.retry import Retry

# ── Configuration ─────────────────────────────────────────────────────────────
load_dotenv()

INPUT_FILE      = os.getenv("INPUT_FILE",      "./sample_input.xlsx")
OUTPUT_FILE     = os.getenv("OUTPUT_FILE",     "./output/ossf_report.xlsx")
CACHE_FILE      = os.getenv("CACHE_FILE",      "./cache/ossf_cache.json")
LOG_FILE        = os.getenv("LOG_FILE",        "./logs/ossf_scorer.log")
MAX_WORKERS     = int(os.getenv("MAX_WORKERS",     "5"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))
CACHE_TTL_HOURS = int(os.getenv("CACHE_TTL_HOURS", "24"))
HTTPS_PROXY     = os.getenv("HTTPS_PROXY", "")
LOG_LEVEL       = os.getenv("LOG_LEVEL",  "INFO")
CLEAR_CACHE     = os.getenv("CLEAR_CACHE", "false").lower() == "true"

DEPS_DEV_URL  = "https://api.deps.dev/v3/systems/maven/packages/{name}/versions/{version}"
SCORECARD_URL = "https://api.scorecard.dev/projects/{repo}"


# ── Logging ───────────────────────────────────────────────────────────────────
def _setup_logging() -> logging.Logger:
    log_dir = os.path.dirname(LOG_FILE)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    log = logging.getLogger("ossf_scorer")
    log.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    console_handler.setFormatter(logging.Formatter("%(levelname)-8s %(message)s"))

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s  %(levelname)-8s  %(message)s")
    )

    log.addHandler(console_handler)
    log.addHandler(file_handler)
    return log


logger = _setup_logging()


# ── Cache helpers ─────────────────────────────────────────────────────────────
def load_cache() -> dict:
    if CLEAR_CACHE or not os.path.exists(CACHE_FILE):
        return {"deps_dev": {}, "scorecard": {}}
    try:
        with open(CACHE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning(f"Could not load cache ({exc}); starting fresh.")
        return {"deps_dev": {}, "scorecard": {}}


def save_cache(cache: dict) -> None:
    cache_dir = os.path.dirname(CACHE_FILE)
    if cache_dir:
        os.makedirs(cache_dir, exist_ok=True)
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2)
        logger.debug("Cache saved.")
    except OSError as exc:
        logger.error(f"Failed to save cache: {exc}")


def _cache_fresh(entry: dict) -> bool:
    ts = entry.get("cached_at")
    if not ts:
        return False
    cached_dt = datetime.fromisoformat(ts)
    if cached_dt.tzinfo is None:
        cached_dt = cached_dt.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) - cached_dt < timedelta(hours=CACHE_TTL_HOURS)


# ── HTTP session ──────────────────────────────────────────────────────────────
def _make_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    if HTTPS_PROXY:
        session.proxies = {"https": HTTPS_PROXY, "http": HTTPS_PROXY}
    return session


# ── Date formatting ───────────────────────────────────────────────────────────
def _friendly_date(date_str: str) -> str:
    """Convert API date string (YYYY-MM-DD) to 'YYYY-MM-DD (X ago)' format."""
    if not date_str:
        return ""
    try:
        score_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        delta = (datetime.now(timezone.utc).date() - score_date).days
        if delta < 0:
            human = "in the future"
        elif delta == 0:
            human = "today"
        elif delta == 1:
            human = "yesterday"
        elif delta < 7:
            human = f"{delta} days ago"
        elif delta < 60:
            weeks = delta // 7
            human = f"about {weeks} week{'s' if weeks != 1 else ''} ago"
        else:
            months = delta // 30
            human = f"about {months} month{'s' if months != 1 else ''} ago"
        return f"{date_str} ({human})"
    except ValueError:
        return date_str


# ── deps.dev API ──────────────────────────────────────────────────────────────
def _call_deps_dev(library_name: str, version: str,
                   session: requests.Session) -> tuple[str | None, str]:
    """
    Returns (repo_or_None, status_string).

    Repo format: 'github.com/owner/repo'
    Status values:
      OK | Library not found in deps.dev | Not scored (non-GitHub repo)
      | Repo not found | deps.dev error: <detail>
    """
    encoded_name    = quote(library_name, safe="")
    encoded_version = quote(version, safe="")
    url = DEPS_DEV_URL.format(name=encoded_name, version=encoded_version)
    logger.debug(f"deps.dev GET {url}")

    try:
        r = session.get(url, timeout=REQUEST_TIMEOUT)
        logger.debug(f"deps.dev → {r.status_code} for {library_name}@{version}")
    except requests.RequestException as exc:
        return None, f"deps.dev error: {exc}"

    if r.status_code == 404:
        return None, "Library not found in deps.dev"
    if r.status_code != 200:
        return None, f"deps.dev error: {r.status_code}"

    data = r.json()

    # Primary source: relatedProjects (most reliable)
    for p in data.get("relatedProjects", []):
        if p.get("relationType") == "SOURCE_REPO":
            pid = p.get("projectKey", {}).get("id", "")
            if pid.startswith("github.com/"):
                return pid, "OK"
            return None, "Not scored (non-GitHub repo)"

    # Fallback: links array
    for link in data.get("links", []):
        if link.get("label") == "SOURCE_REPO":
            link_url = link.get("url", "")
            m = re.search(r"github\.com/([^/]+)/([^/.\s]+)", link_url)
            if m:
                return f"github.com/{m.group(1)}/{m.group(2)}", "OK"
            return None, "Not scored (non-GitHub repo)"

    return None, "Repo not found"


def resolve_repo(library_name: str, version: str,
                 cache: dict, cache_lock: threading.Lock,
                 session: requests.Session) -> tuple[str | None, str]:
    """Cache-aware wrapper around _call_deps_dev."""
    key = f"{library_name}@{version}"

    with cache_lock:
        entry = cache["deps_dev"].get(key)
        if entry and _cache_fresh(entry):
            logger.debug(f"Cache hit [deps.dev]: {key}")
            return entry["repo"], entry["status"]

    # API call outside the lock so other threads can proceed
    repo, status = _call_deps_dev(library_name, version, session)

    with cache_lock:
        cache["deps_dev"][key] = {
            "repo":      repo,
            "status":    status,
            "cached_at": datetime.now(timezone.utc).isoformat(),
        }

    return repo, status


# ── Scorecard API ─────────────────────────────────────────────────────────────
def _call_scorecard(repo: str, session: requests.Session) -> dict:
    """
    Returns dict with keys: score, date, checks, status.
    Status values: OK | Not scored | Rate limited | scorecard error: <detail>
    """
    url = SCORECARD_URL.format(repo=repo)
    logger.debug(f"Scorecard GET {url}")

    try:
        r = session.get(url, timeout=REQUEST_TIMEOUT)
        logger.debug(f"Scorecard → {r.status_code} for {repo}")
    except requests.RequestException as exc:
        return {"score": None, "date": None, "checks": [], "status": f"scorecard error: {exc}"}

    if r.status_code == 404:
        return {"score": None, "date": None, "checks": [], "status": "Not scored"}
    if r.status_code == 429:
        return {"score": None, "date": None, "checks": [], "status": "Rate limited"}
    if r.status_code != 200:
        return {"score": None, "date": None, "checks": [], "status": f"scorecard error: {r.status_code}"}

    data = r.json()
    return {
        "score":  data.get("score"),
        "date":   data.get("date"),
        "checks": data.get("checks", []),
        "status": "OK",
    }


def fetch_scorecard(repo: str,
                    cache: dict, cache_lock: threading.Lock,
                    session: requests.Session) -> dict:
    """Cache-aware wrapper around _call_scorecard."""
    with cache_lock:
        entry = cache["scorecard"].get(repo)
        if entry and _cache_fresh(entry):
            logger.debug(f"Cache hit [scorecard]: {repo}")
            return entry

    result = _call_scorecard(repo, session)
    result["cached_at"] = datetime.now(timezone.utc).isoformat()

    with cache_lock:
        cache["scorecard"][repo] = result

    return result


# ── Row processor ─────────────────────────────────────────────────────────────
def process_row(row: dict,
                cache: dict, cache_lock: threading.Lock,
                session: requests.Session) -> tuple[dict, list]:
    """
    Process one input row.
    Returns (summary_dict, list_of_detail_dicts).
    """
    library_name = str(row["Library Name"]).strip()
    version      = str(row["Current Version"]).strip()

    summary = {
        "Library Name":    library_name,
        "Current Version": version,
        "OpenSSF Score":      None,
        "Scorecard Date":  "",
        "Repo URL":        "",
        "Status":          "",
    }
    details: list[dict] = []

    # ── Step 1: resolve GitHub repo via deps.dev ──────────────────────────────
    repo, deps_status = resolve_repo(library_name, version, cache, cache_lock, session)
    summary["Repo URL"] = repo or ""
    summary["Status"]   = deps_status

    if repo is None:
        logger.warning(f"{library_name}@{version} → {deps_status}")
        return summary, details

    # ── Step 2: fetch OpenSSF Scorecard ───────────────────────────────────────
    sc = fetch_scorecard(repo, cache, cache_lock, session)
    summary["Status"] = sc["status"]

    if sc["status"] == "OK":
        summary["OpenSSF Score"]     = sc["score"]
        summary["Scorecard Date"] = _friendly_date(sc.get("date") or "")

        for check in sc.get("checks", []):
            details.append({
                "Library Name":        library_name,
                "Current Version":     version,
                "Check Name":          check.get("name", ""),
                "Check Score":         check.get("score"),   # -1 means N/A
                "Reason":              check.get("reason", ""),
                "Details":             "\n".join(check.get("details") or []),
                "Documentation Short": check.get("documentation", {}).get("short", ""),
                "Documentation URL":   check.get("documentation", {}).get("url", ""),
            })

        logger.info(
            f"OK  {library_name}@{version}  score={sc['score']}  repo={repo}"
        )
    else:
        logger.warning(f"{library_name}@{version} → {sc['status']}")

    return summary, details


# ── Excel writer ──────────────────────────────────────────────────────────────
# Column name → display width (characters)
SUMMARY_COLS: dict[str, tuple[str, int]] = {
    "A": ("Library Name",    55),
    "B": ("Current Version", 20),
    "C": ("OpenSSF Score",      12),
    "D": ("Scorecard Date",  34),
    "E": ("Repo URL",        50),
    "F": ("Status",          38),
}

DETAIL_COLS: dict[str, tuple[str, int]] = {
    "A": ("Library Name",        55),
    "B": ("Current Version",     20),
    "C": ("Check Name",          22),
    "D": ("Check Score",         13),
    "E": ("Reason",              65),
    "F": ("Details",             85),
    "G": ("Documentation Short", 55),
    "H": ("Documentation URL",   85),
}

_HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
_HEADER_FONT = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
_DATA_FONT   = Font(name="Calibri", size=10)


def _style_sheet(ws, col_meta: dict[str, tuple[str, int]]) -> None:
    """Apply header styling, freeze pane, column widths, and wrap-text."""
    for cell in ws[1]:
        cell.font      = _HEADER_FONT
        cell.fill      = _HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center",
                                   horizontal="center")

    ws.freeze_panes = "A2"

    for col_letter, (_, width) in col_meta.items():
        ws.column_dimensions[col_letter].width = width

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font      = _DATA_FONT
            cell.alignment = Alignment(wrap_text=True, vertical="top")


def write_excel(summary_rows: list[dict], detail_rows: list[dict],
                output_path: str) -> None:
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    summary_col_names = [name for name, _ in SUMMARY_COLS.values()]
    detail_col_names  = [name for name, _ in DETAIL_COLS.values()]

    df_summary = pd.DataFrame(summary_rows, columns=summary_col_names)
    df_details = (
        pd.DataFrame(detail_rows, columns=detail_col_names)
        if detail_rows
        else pd.DataFrame(columns=detail_col_names)
    )

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df_summary.to_excel(writer, sheet_name="Summary",      index=False)
        df_details.to_excel(writer, sheet_name="Check Details", index=False)
        _style_sheet(writer.sheets["Summary"],       SUMMARY_COLS)
        _style_sheet(writer.sheets["Check Details"], DETAIL_COLS)

    logger.info(f"Output written → {output_path}")


# ── Input reader ──────────────────────────────────────────────────────────────
def read_input(path: str) -> list[dict]:
    try:
        tabs = pd.read_excel(path, sheet_name=None, dtype=str)
    except FileNotFoundError:
        logger.error(f"Input file not found: {path}")
        sys.exit(1)
    except Exception as exc:
        logger.error(f"Failed to read input file: {exc}")
        sys.exit(1)

    rows: list[dict] = []
    for tab_name, df in tabs.items():
        if "Library Name" not in df.columns or "Current Version" not in df.columns:
            logger.warning(f"Tab '{tab_name}' is missing required columns – skipping.")
            continue
        valid = df[["Library Name", "Current Version"]].dropna(
            subset=["Library Name", "Current Version"]
        )
        logger.info(f"Tab '{tab_name}': {len(valid)} rows")
        rows.extend(valid.to_dict("records"))

    if not rows:
        logger.error("No valid rows found across all tabs. Check column names.")
        sys.exit(1)

    logger.info(f"Total rows to process: {len(rows)}")
    return rows


# ── Pre-flight connectivity check ─────────────────────────────────────────────
def _preflight(session: requests.Session) -> None:
    """Fail fast if either API is unreachable."""
    probes = [
        ("deps.dev",   "https://api.deps.dev/v3/systems/maven/packages/org.slf4j%3Aslf4j-api/versions/2.0.13"),
        ("Scorecard",  "https://api.scorecard.dev/projects/github.com/qos-ch/slf4j"),
    ]
    for name, url in probes:
        try:
            r = session.get(url, timeout=10)
            logger.debug(f"Preflight {name}: {r.status_code}")
        except requests.RequestException as exc:
            logger.error(
                f"Cannot reach {name} API ({url}).\n"
                f"  Error: {exc}\n"
                f"  Check HTTPS_PROXY setting or network access."
            )
            sys.exit(1)
    logger.info("Preflight checks passed (deps.dev ✓  Scorecard ✓)")


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    logger.info("=" * 65)
    logger.info(f"  OpenSSF Scorer  –  Run started {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 65)
    logger.info(f"  Input        : {INPUT_FILE}")
    logger.info(f"  Output       : {OUTPUT_FILE}")
    logger.info(f"  Cache file   : {CACHE_FILE}")
    logger.info(f"  Cache TTL    : {CACHE_TTL_HOURS}h  (clear={CLEAR_CACHE})")
    logger.info(f"  Workers      : {MAX_WORKERS}")
    logger.info(f"  Proxy        : {HTTPS_PROXY or '(none)'}")
    logger.info("=" * 65)

    rows       = read_input(INPUT_FILE)
    cache      = load_cache()
    cache_lock = threading.Lock()
    session    = _make_session()

    if CLEAR_CACHE:
        logger.info("Cache cleared (CLEAR_CACHE=true)")

    # Save cache on Ctrl-C so partial progress is not lost
    def _on_interrupt(sig, frame):
        print()
        logger.info("Interrupted – saving cache before exit…")
        save_cache(cache)
        sys.exit(0)
    signal.signal(signal.SIGINT, _on_interrupt)

    # ── Preflight ─────────────────────────────────────────────────────────────
    _preflight(session)

    # ── Process rows concurrently ─────────────────────────────────────────────
    ordered_results: list[tuple[dict, list] | None] = [None] * len(rows)
    stats = {"ok": 0, "not_scored": 0, "errors": 0}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_idx = {
            executor.submit(process_row, row, cache, cache_lock, session): i
            for i, row in enumerate(rows)
        }

        with tqdm(total=len(rows), desc="Processing libraries",
                  unit="lib", dynamic_ncols=True) as pbar:
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    summary, details = future.result()
                    ordered_results[idx] = (summary, details)

                    status = summary.get("Status", "")
                    if status == "OK":
                        stats["ok"] += 1
                    elif "error" in status.lower() or "not found" in status.lower() \
                            or "rate" in status.lower():
                        stats["errors"] += 1
                    else:
                        stats["not_scored"] += 1

                except Exception as exc:
                    logger.error(f"Unexpected error on row {idx}: {exc}")
                    lib  = rows[idx].get("Library Name", "unknown")
                    ver  = rows[idx].get("Current Version", "unknown")
                    ordered_results[idx] = (
                        {
                            "Library Name":    lib,
                            "Current Version": ver,
                            "OpenSSF Score":      None,
                            "Scorecard Date":  "",
                            "Repo URL":        "",
                            "Status":          f"Unexpected error: {exc}",
                        },
                        [],
                    )
                    stats["errors"] += 1
                finally:
                    pbar.update(1)

    # ── Assemble results in original row order ────────────────────────────────
    summary_rows: list[dict] = []
    detail_rows:  list[dict] = []
    for result in ordered_results:
        if result:
            s, d = result
            summary_rows.append(s)
            detail_rows.extend(d)

    # ── Persist cache and write output ────────────────────────────────────────
    save_cache(cache)
    write_excel(summary_rows, detail_rows, OUTPUT_FILE)

    logger.info("=" * 65)
    logger.info(
        f"  Done  ✓ OK={stats['ok']}   "
        f"⚠ Not-scored={stats['not_scored']}   "
        f"✗ Errors={stats['errors']}"
    )
    logger.info(f"  Run ended    : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 65)


if __name__ == "__main__":
    main()
