"""cwe_to_excel — Build a CWE remediation lookup workbook from MITRE's XML feed."""

__version__ = "1.0.0"
