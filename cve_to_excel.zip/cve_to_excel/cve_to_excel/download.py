"""Download a per-year CVE feed from fkie-cad and decompress it."""

from __future__ import annotations

import json
import lzma
import sys

import requests

URL_TEMPLATE = (
    "https://github.com/fkie-cad/nvd-json-data-feeds/releases/latest/download/"
    "CVE-{year}.json.xz"
)


def download_year(year: int, timeout: int = 120) -> tuple[list[dict], str]:
    """Download the per-year CVE feed, decompress, and return (records, source_url).

    Handles both possible top-level shapes:
      * a bare JSON array of NVD-2.0 CVE records, or
      * an NVD-API-style envelope {"vulnerabilities": [...]}.

    Each record in the returned list is the *outer* NVD record (with a `"cve"`
    key when wrapped) — normalization happens during parsing.
    """
    url = URL_TEMPLATE.format(year=year)
    print(f"Downloading {url} ...", file=sys.stderr)
    r = requests.get(url, timeout=timeout, allow_redirects=True)
    r.raise_for_status()

    print(f"Decompressing {len(r.content):,} bytes ...", file=sys.stderr)
    decompressed = lzma.decompress(r.content)

    print(f"Parsing {len(decompressed):,} bytes of JSON ...", file=sys.stderr)
    data = json.loads(decompressed)

    if isinstance(data, list):
        records = data
    elif isinstance(data, dict) and "vulnerabilities" in data:
        records = data["vulnerabilities"]
    elif isinstance(data, dict) and "cve_items" in data:
        # tolerate yet another plausible wrapper
        records = data["cve_items"]
    else:
        raise ValueError(
            f"Unexpected feed shape for year {year}: "
            f"top-level type {type(data).__name__}, "
            f"keys {list(data)[:5] if isinstance(data, dict) else 'n/a'}"
        )

    print(f"Loaded {len(records):,} CVE records.", file=sys.stderr)
    return records, url
