"""Download and unzip MITRE's CWE catalog XML."""

from __future__ import annotations

import io
import re
import sys
import zipfile

import requests

LATEST_URL = "https://cwe.mitre.org/data/xml/cwec_latest.xml.zip"
VERSIONED_URL = "https://cwe.mitre.org/data/xml/cwec_v{version}.xml.zip"


def download_xml(version: str | None = None, timeout: int = 60) -> tuple[bytes, str, str]:
    """Fetch the CWE XML zip, extract it, and return (xml_bytes, version, source_url).

    If `version` is None, the latest catalog is downloaded.
    """
    url = LATEST_URL if version is None else VERSIONED_URL.format(version=version)
    print(f"Downloading {url} ...", file=sys.stderr)
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(r.content)) as zf:
        xml_name = next(n for n in zf.namelist() if n.endswith(".xml"))
        m = re.search(r"cwec_v([\d.]+)\.xml", xml_name)
        detected = m.group(1) if m else "unknown"
        return zf.read(xml_name), detected, url
