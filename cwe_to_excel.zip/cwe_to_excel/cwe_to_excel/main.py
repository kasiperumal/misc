"""CLI entry point: orchestrates download -> parse -> export."""

from __future__ import annotations

import argparse
from pathlib import Path

from .download import download_xml
from .export import write_workbook
from .parse import parse_weaknesses


def main() -> None:
    ap = argparse.ArgumentParser(
        prog="cwe_to_excel",
        description="Build a CWE remediation lookup workbook from MITRE's official XML feed.",
    )
    ap.add_argument(
        "--output", "-o",
        default="cwe_lookup.xlsx",
        help="Output .xlsx path (default: ./cwe_lookup.xlsx)",
    )
    ap.add_argument(
        "--version", "-v",
        default=None,
        help="Specific CWE version (e.g. 4.20). Default: latest.",
    )
    args = ap.parse_args()

    xml_bytes, version, source_url = download_xml(args.version)
    rows = parse_weaknesses(xml_bytes)
    write_workbook(rows, version, source_url, Path(args.output))


if __name__ == "__main__":
    main()
