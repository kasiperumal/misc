"""Pure text transformations: XHTML -> plain text, truncation, block joining."""

from __future__ import annotations

import re

from lxml import etree

# Excel hard cap on a single cell
CELL_LIMIT = 32_767
TRUNCATE_MARKER = " […truncated]"

# Separator used between entries of multi-valued fields (e.g. multiple mitigations)
BLOCK_SEP = "\n---\n"


def xhtml_to_text(elem) -> str:
    """Flatten an element (which may contain XHTML markup) into plain text.

    - <br/>            -> '\\n'
    - <p>, <div>       -> trailing '\\n\\n' (paragraph break)
    - <li>             -> leading '\\n• '
    - everything else  -> inline text
    """
    if elem is None:
        return ""

    parts: list[str] = []

    def walk(node):
        tag = etree.QName(node).localname if isinstance(node.tag, str) else None
        if tag == "br":
            parts.append("\n")
        elif tag == "li":
            parts.append("\n• ")
        if node.text:
            parts.append(node.text)
        for child in node:
            walk(child)
            if child.tail:
                parts.append(child.tail)
        if tag in ("p", "div"):
            parts.append("\n\n")

    walk(elem)
    text = "".join(parts)
    text = re.sub(r"[ \t]+", " ", text)        # collapse runs of spaces/tabs
    text = re.sub(r" *\n *", "\n", text)       # strip spaces around newlines
    text = re.sub(r"\n{3,}", "\n\n", text)     # collapse triple+ newlines
    return text.strip()


def join_blocks(blocks: list[str]) -> str:
    """Join non-empty blocks with the standard separator."""
    return BLOCK_SEP.join(b for b in blocks if b)


def truncate(text: str) -> str:
    """Truncate to Excel's per-cell limit, appending a marker if cut."""
    if len(text) <= CELL_LIMIT:
        return text
    return text[: CELL_LIMIT - len(TRUNCATE_MARKER)] + TRUNCATE_MARKER
