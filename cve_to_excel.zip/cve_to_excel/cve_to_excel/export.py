"""Write parsed CVE rows to a formatted .xlsx file."""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .transform import CELL_LIMIT, truncate

COLUMNS: list[tuple[str, int]] = [
    ("CVE-ID", 18),
    ("Status", 18),
    ("Published Date (UTC)", 22),
    ("Last Modified Date (UTC)", 22),
    ("Description", 70),
    ("CWE-IDs", 24),
    ("CVSS v3.x Version", 12),
    ("CVSS v3.x Base Score", 14),
    ("CVSS v3.x Severity", 14),
    ("CVSS v3.x Vector", 40),
    ("CVSS v4.0 Base Score", 14),
    ("CVSS v4.0 Severity", 14),
    ("Attack Vector", 14),
    ("Attack Complexity", 16),
    ("Privileges Required", 16),
    ("User Interaction", 14),
    ("Affected Products", 50),
]


def write_workbook(
    rows: list[dict],
    year: int,
    source_url: str,
    stats: dict,
    out_path: Path,
) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "CVE Lookup"

    headers = [c[0] for c in COLUMNS]
    widths = [c[1] for c in COLUMNS]

    # Header styling
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", start_color="1F4E78")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for c_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    body_font = Font(name="Calibri", size=10)
    body_align = Alignment(vertical="top", wrap_text=True)
    truncated = 0
    for r_idx, row in enumerate(rows, start=2):
        for c_idx, header in enumerate(headers, start=1):
            value = row.get(header, "")
            if isinstance(value, str):
                if len(value) > CELL_LIMIT:
                    truncated += 1
                    value = truncate(value)
            elif value == "":
                value = None  # leave the cell blank rather than empty-string
            cell = ws.cell(row=r_idx, column=c_idx, value=value)
            cell.font = body_font
            cell.alignment = body_align

    for c_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c_idx)].width = width

    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions

    # Metadata sheet
    meta = wb.create_sheet("Metadata")
    bold = Font(name="Calibri", bold=True)
    plain = Font(name="Calibri", size=10)
    meta["A1"] = "Field"
    meta["B1"] = "Value"
    meta["A1"].font = bold
    meta["B1"].font = bold

    meta_rows: list[tuple[str, object]] = [
        ("Year", year),
        ("Source URL", source_url),
        ("Generated At (UTC)", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")),
        ("Severity filter", ", ".join(stats["included_severities"])),
        ("Total records in feed", stats["total_records"]),
        ("Rows included in workbook", stats["included"]),
        ("Rejected CVEs filtered out", stats["rejected_filtered_out"]),
        ("Filtered out by severity (below threshold)", stats["filtered_by_severity"]),
        ("Filtered out — no score at all", stats["no_score_filtered_out"]),
        ("Included CVEs without v3.x score", stats["no_v3_score"]),
        ("Included CVEs with v4.0 score", stats["has_v4_score"]),
        ("Truncated cells", truncated),
        ("", ""),  # spacer
        ("Included severity breakdown", ""),
    ]
    for sev in stats["included_severities"]:
        meta_rows.append((f"  {sev}", stats["severity_counts"].get(sev, 0)))

    meta_rows.append(("", ""))  # spacer
    meta_rows.append(("Status breakdown (full feed)", ""))
    for status, count in sorted(stats["status_counts"].items(), key=lambda kv: -kv[1]):
        meta_rows.append((f"  {status or '(no status)'}", count))

    for i, (k, v) in enumerate(meta_rows, start=2):
        meta.cell(row=i, column=1, value=k).font = plain
        meta.cell(row=i, column=2, value=v).font = plain
    meta.column_dimensions["A"].width = 32
    meta.column_dimensions["B"].width = 70

    wb.save(out_path)
    sev_filter = "/".join(stats["included_severities"])
    print(
        f"Wrote {out_path} — {len(rows):,} rows for CVE-{year} "
        f"(severity={sev_filter}; "
        f"filtered {stats['rejected_filtered_out']:,} Rejected, "
        f"{stats['filtered_by_severity']:,} below threshold, "
        f"{stats['no_score_filtered_out']:,} without score; "
        f"{truncated} truncated cell(s))",
        file=sys.stderr,
    )
