"""Parse CWE XML into a list of flat dicts ready for Excel export."""

from __future__ import annotations

from lxml import etree

from .transform import join_blocks, xhtml_to_text

CWE_NS = "http://cwe.mitre.org/cwe-7"
XHTML_NS = "http://www.w3.org/1999/xhtml"
NS = {"cwe": CWE_NS, "xhtml": XHTML_NS}


def get_text(parent, xpath: str) -> str:
    el = parent.find(xpath, NS)
    return xhtml_to_text(el) if el is not None else ""


def build_external_refs_map(root) -> dict[str, str]:
    """Map each External_Reference_ID to a formatted citation string."""
    refs: dict[str, str] = {}
    for r in root.findall("cwe:External_References/cwe:External_Reference", NS):
        rid = r.get("Reference_ID", "")
        authors = [a.text for a in r.findall("cwe:Author", NS) if a.text]
        title_el = r.find("cwe:Title", NS)
        url_el = r.find("cwe:URL", NS)
        year_el = r.find("cwe:Publication_Year", NS)
        publisher_el = r.find("cwe:Publisher", NS)

        bits = []
        if authors:
            bits.append(", ".join(authors))
        if year_el is not None and year_el.text:
            bits.append(f"({year_el.text})")
        if title_el is not None and title_el.text:
            bits.append(f'"{title_el.text}"')
        if publisher_el is not None and publisher_el.text:
            bits.append(publisher_el.text)
        if url_el is not None and url_el.text:
            bits.append(url_el.text)
        refs[rid] = ". ".join(bits) if bits else rid
    return refs


def extract_consequences(w) -> str:
    out = []
    for c in w.findall("cwe:Common_Consequences/cwe:Consequence", NS):
        scopes = [s.text for s in c.findall("cwe:Scope", NS) if s.text]
        impacts = [i.text for i in c.findall("cwe:Impact", NS) if i.text]
        note = get_text(c, "cwe:Note")
        block = []
        if scopes:
            block.append(f"Scope: {', '.join(scopes)}")
        if impacts:
            block.append(f"Impact: {', '.join(impacts)}")
        if note:
            block.append(f"Note: {note}")
        if block:
            out.append("\n".join(block))
    return join_blocks(out)


def extract_mitigations(w) -> str:
    out = []
    for m in w.findall("cwe:Potential_Mitigations/cwe:Mitigation", NS):
        phases = [p.text for p in m.findall("cwe:Phase", NS) if p.text]
        strategy = m.findtext("cwe:Strategy", default="", namespaces=NS)
        eff = m.findtext("cwe:Effectiveness", default="", namespaces=NS)
        desc = get_text(m, "cwe:Description")
        block = []
        if phases:
            block.append(f"Phase: {', '.join(phases)}")
        if strategy:
            block.append(f"Strategy: {strategy}")
        if eff:
            block.append(f"Effectiveness: {eff}")
        if desc:
            block.append(desc)
        if block:
            out.append("\n".join(block))
    return join_blocks(out)


def extract_detection_methods(w) -> str:
    out = []
    for d in w.findall("cwe:Detection_Methods/cwe:Detection_Method", NS):
        method = d.findtext("cwe:Method", default="", namespaces=NS)
        eff = d.findtext("cwe:Effectiveness", default="", namespaces=NS)
        desc = get_text(d, "cwe:Description")
        block = []
        if method:
            block.append(f"Method: {method}")
        if eff:
            block.append(f"Effectiveness: {eff}")
        if desc:
            block.append(desc)
        if block:
            out.append("\n".join(block))
    return join_blocks(out)


def extract_demonstrative_examples(w) -> str:
    out = []
    for ex in w.findall("cwe:Demonstrative_Examples/cwe:Demonstrative_Example", NS):
        parts = []
        for child in ex:
            tag = etree.QName(child).localname
            if tag in ("Intro_Text", "Body_Text"):
                t = xhtml_to_text(child)
                if t:
                    parts.append(t)
            elif tag == "Example_Code":
                nature = child.get("Nature", "")
                lang = child.get("Language", "")
                code_text = xhtml_to_text(child)
                header = f"[{nature}{' / ' + lang if lang else ''}]"
                parts.append(f"{header}\n{code_text}".rstrip())
        if parts:
            out.append("\n".join(parts))
    return join_blocks(out)


def extract_observed_examples(w) -> str:
    out = []
    for ex in w.findall("cwe:Observed_Examples/cwe:Observed_Example", NS):
        ref = ex.findtext("cwe:Reference", default="", namespaces=NS)
        desc = ex.findtext("cwe:Description", default="", namespaces=NS)
        link = ex.findtext("cwe:Link", default="", namespaces=NS)
        bits = [b for b in (ref, desc, link) if b]
        if bits:
            out.append(" — ".join(bits))
    return "\n".join(out)


def extract_related_weaknesses(w) -> str:
    out = []
    for r in w.findall("cwe:Related_Weaknesses/cwe:Related_Weakness", NS):
        nature = r.get("Nature", "")
        cwe_id = r.get("CWE_ID", "")
        view = r.get("View_ID", "")
        if view:
            out.append(f"{nature}: CWE-{cwe_id} (View {view})")
        else:
            out.append(f"{nature}: CWE-{cwe_id}")
    return "\n".join(out)


def extract_platforms(w) -> str:
    out = []
    for p in w.findall("cwe:Applicable_Platforms/*", NS):
        kind = etree.QName(p).localname  # Language / OS / Architecture / Technology
        name = p.get("Name") or p.get("Class", "Any")
        prev = p.get("Prevalence", "")
        out.append(f"{kind}: {name} ({prev})" if prev else f"{kind}: {name}")
    return "\n".join(out)


def extract_references(w, ext_map: dict[str, str]) -> str:
    out = []
    for ref in w.findall("cwe:References/cwe:Reference", NS):
        rid = ref.get("External_Reference_ID", "")
        section = ref.get("Section", "")
        resolved = ext_map.get(rid, rid)
        out.append(f"{resolved} — {section}" if section else resolved)
    return "\n".join(out)


def parse_weaknesses(xml_bytes: bytes) -> list[dict]:
    """Parse the catalog and return one flat dict per Weakness, sorted by CWE-ID."""
    root = etree.fromstring(xml_bytes)
    ext_map = build_external_refs_map(root)
    rows: list[dict] = []
    for w in root.findall("cwe:Weaknesses/cwe:Weakness", NS):
        rows.append({
            "CWE-ID": f"CWE-{w.get('ID')}",
            "Name": w.get("Name", ""),
            "Abstraction": w.get("Abstraction", ""),
            "Status": w.get("Status", ""),
            "Description": get_text(w, "cwe:Description"),
            "Extended Description": get_text(w, "cwe:Extended_Description"),
            "Common Consequences": extract_consequences(w),
            "Potential Mitigations": extract_mitigations(w),
            "Detection Methods": extract_detection_methods(w),
            "Demonstrative Examples": extract_demonstrative_examples(w),
            "Observed Examples": extract_observed_examples(w),
            "Related Weaknesses": extract_related_weaknesses(w),
            "Applicable Platforms": extract_platforms(w),
            "References": extract_references(w, ext_map),
        })
    rows.sort(key=lambda r: int(r["CWE-ID"].split("-")[1]))
    return rows
