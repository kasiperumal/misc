# cve_to_excel

Build a per-year CVE remediation lookup `.xlsx` from the
[fkie-cad NVD JSON data feeds](https://github.com/fkie-cad/nvd-json-data-feeds).

**Only CRITICAL and HIGH severity CVEs are included.** A CVE is kept if either
its CVSS v3.x severity *or* its CVSS v4.0 severity is `CRITICAL` or `HIGH`.
The following are filtered out and counted on the Metadata sheet:

- CVEs with `vulnStatus == "Rejected"`
- CVEs whose severity is below HIGH (MEDIUM / LOW / NONE)
- CVEs with no CVSS score at all (e.g. `Awaiting Analysis`)

To change the threshold, edit `INCLUDED_SEVERITIES` near the top of
`cve_to_excel/parse.py` (e.g. add `"MEDIUM"` to widen the filter).

## Install

```bash
pip install -r requirements.txt
```

Requires Python 3.9+. No NVD API key needed.

## Usage

Run from the directory that contains the `cve_to_excel/` package folder:

```bash
# One year, default output ./cve_lookup_2024.xlsx
python -m cve_to_excel --year 2024

# Custom output path
python -m cve_to_excel --year 2024 -o /path/cve_2024.xlsx
```

To produce multiple years, loop:

```bash
for y in 2022 2023 2024 2025; do
  python -m cve_to_excel --year "$y"
done
```

## Output

A single `.xlsx` per run with two sheets:

- **CVE Lookup** — one row per included (CRITICAL/HIGH) CVE for the year.
  Header row is frozen, autofilter is enabled, long text wraps within cells.
- **Metadata** — year, source URL, severity filter, generation timestamp UTC,
  totals, rejected count, below-threshold count, no-score count, no-v3 count,
  has-v4 count, truncated-cell count, severity breakdown, and full status
  breakdown of the source feed.

## Columns

`CVE-ID`, `Status`, `Published Date (UTC)`, `Last Modified Date (UTC)`,
`Description`, `CWE-IDs`, `CVSS v3.x Version`, `CVSS v3.x Base Score`,
`CVSS v3.x Severity`, `CVSS v3.x Vector`, `CVSS v4.0 Base Score`,
`CVSS v4.0 Severity`, `Attack Vector`, `Attack Complexity`,
`Privileges Required`, `User Interaction`, `Affected Products`.

### Notes

- **CVSS selection:** when a CVE has multiple evaluators (NIST + vendor CNA),
  the entry with `type == "Primary"` is chosen; otherwise the first one.
- **CVSS v3.x version column** records which v3 sub-version was used (3.1
  preferred, falls back to 3.0).
- **Attack Vector / Complexity / Privileges Required / User Interaction**
  columns are parsed from the v3.x vector string with codes expanded
  (`N` → `Network`, `L` → `Low`, …). Blank if no v3.x score is available.
- **CWE-IDs** is a comma-separated list. Placeholder values like
  `NVD-CWE-Other` / `NVD-CWE-noinfo` are passed through so you can see when
  classification was incomplete.
- **Affected Products** is a flattened summary: one line per unique
  `vendor:product`, with version ranges in parentheses (e.g.
  `acme:webapp (≥ 1.0 and < 1.5, 2.0)`). Full CPE 2.3 strings are not exported.
- Cells exceeding Excel's 32,767-char hard limit are truncated with a
  ` […truncated]` marker.

## Project layout

```
cve_to_excel/
  __init__.py
  __main__.py     # `python -m cve_to_excel` entry
  download.py     # fetch the year's .xz file and decompress + shape-detect
  parse.py        # NVD 2.0 JSON record -> flat dict (filters Rejected)
  transform.py    # CVSS vector parsing, datetime, truncation helpers
  export.py       # write .xlsx with formatting + metadata sheet
  main.py         # CLI: --year (required), --output
```

## Programmatic use

```python
from pathlib import Path
from cve_to_excel.download import download_year
from cve_to_excel.parse import parse_records
from cve_to_excel.export import write_workbook

records, source_url = download_year(2024)
rows, stats = parse_records(records)
write_workbook(rows, 2024, source_url, stats, Path("cve_lookup_2024.xlsx"))
```

## Memory note

Recent years contain 28K–35K CVEs and decompress to ~150–300 MB of JSON.
Peak memory during parsing is roughly 1 GB. If that's a concern on small
VMs, switch the parser to streaming with `ijson`; for typical
developer laptops the default full-load is fine.
