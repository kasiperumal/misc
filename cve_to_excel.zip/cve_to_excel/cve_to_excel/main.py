"""CLI entry point: orchestrates download -> parse -> export for one year."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

from .download import download_year
from .export import write_workbook
from .parse import parse_records


def _valid_year(s: str) -> int:
    try:
        y = int(s)
    except ValueError:
        raise argparse.ArgumentTypeError(f"--year must be an integer, got {s!r}")
    current = datetime.utcnow().year
    if y < 1999 or y > current:
        raise argparse.ArgumentTypeError(
            f"--year must be between 1999 and {current}, got {y}"
        )
    return y


def main() -> None:
    ap = argparse.ArgumentParser(
        prog="cve_to_excel",
        description=(
            "Build a per-year CVE remediation lookup workbook from the "
            "fkie-cad NVD JSON data feeds. Only CRITICAL and HIGH severity "
            "CVEs are written; Rejected and unscored CVEs are filtered out."
        ),
    )
    ap.add_argument(
        "--year", "-y",
        required=True,
        type=_valid_year,
        help="CVE year to download (e.g. 2024). Range: 1999..current year.",
    )
    ap.add_argument(
        "--output", "-o",
        default=None,
        help="Output .xlsx path (default: ./cve_lookup_<year>.xlsx).",
    )
    args = ap.parse_args()

    out_path = Path(args.output) if args.output else Path(f"cve_lookup_{args.year}.xlsx")

    records, source_url = download_year(args.year)
    rows, stats = parse_records(records)
    write_workbook(rows, args.year, source_url, stats, out_path)


if __name__ == "__main__":
    main()
