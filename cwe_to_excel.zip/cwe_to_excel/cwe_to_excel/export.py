"""Write parsed CWE rows to a formatted .xlsx file."""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .transform import CELL_LIMIT, truncate

COLUMNS: list[tuple[str, int]] = [
    ("CWE-ID", 12),
    ("Name", 40),
    ("Abstraction", 14),
    ("Status", 12),
    ("Description", 60),
    ("Extended Description", 60),
    ("Common Consequences", 55),
    ("Potential Mitigations", 70),
    ("Detection Methods", 50),
    ("Demonstrative Examples", 60),
    ("Observed Examples", 50),
    ("Related Weaknesses", 30),
    ("Applicable Platforms", 30),
    ("References", 50),
]


def write_workbook(rows: list[dict], version: str, source_url: str, out_path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "CWE Lookup"

    headers = [c[0] for c in COLUMNS]
    widths = [c[1] for c in COLUMNS]

    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", start_color="1F4E78")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for c_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    body_font = Font(name="Calibri", size=10)
    body_align = Alignment(vertical="top", wrap_text=True)
    truncated = 0
    for r_idx, row in enumerate(rows, start=2):
        for c_idx, header in enumerate(headers, start=1):
            raw = str(row.get(header, ""))
            if len(raw) > CELL_LIMIT:
                truncated += 1
            cell = ws.cell(row=r_idx, column=c_idx, value=truncate(raw))
            cell.font = body_font
            cell.alignment = body_align

    for c_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c_idx)].width = width

    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions

    # Metadata sheet
    meta = wb.create_sheet("Metadata")
    meta_rows = [
        ("CWE Version", version),
        ("Source URL", source_url),
        ("Generated At (UTC)", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")),
        ("Total Weaknesses", len(rows)),
        ("Truncated Cells", truncated),
    ]
    bold = Font(name="Calibri", bold=True)
    plain = Font(name="Calibri", size=10)
    meta["A1"] = "Field"
    meta["B1"] = "Value"
    meta["A1"].font = bold
    meta["B1"].font = bold
    for i, (k, v) in enumerate(meta_rows, start=2):
        meta.cell(row=i, column=1, value=k).font = plain
        meta.cell(row=i, column=2, value=v).font = plain
    meta.column_dimensions["A"].width = 22
    meta.column_dimensions["B"].width = 70

    wb.save(out_path)
    print(
        f"Wrote {out_path} — {len(rows)} weaknesses, CWE v{version}, "
        f"{truncated} truncated cell(s)",
        file=sys.stderr,
    )
